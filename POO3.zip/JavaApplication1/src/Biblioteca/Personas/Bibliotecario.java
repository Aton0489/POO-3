/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Biblioteca.Personas;

/**
 *
 * @author omuri
 */
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Bibliotecario extends Usuario{
    private int Contraseña;


    //constructor
    public Bibliotecario(int id, String Nombre,String Telefono, String Correo, int Contraseña){
        super(id, Nombre, Telefono, Correo);
        this.Contraseña = Contraseña;
    }
    //Getters



    //Contraseña
    public int getContraseña(){
        return Contraseña;
    }

    //Setter

    //contraseña
    public void setContraseña(int Contraseña){
        this.Contraseña = Contraseña;
    }


    //RegistrarLibro
    public Libro registrarLibro(Libro libro){

        // Se solicita al bibliotecario que ingrese los detalles del nuevo libro
        int id = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el ID del libro:"));
        libro.setidLiblo(id);
        String Titulo = JOptionPane.showInputDialog("Ingrese el título del libro:");
        libro.setTitulo(Titulo);
        String Autor = JOptionPane.showInputDialog("Ingrese el autor del libro:");
        libro.setAutor(Autor);
        String Genero = JOptionPane.showInputDialog("Ingrese el género del libro:");
        libro.setGenero(Genero);
        int AñoPublicacion = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el año de publicación del libro:"));
        libro.setAñoPublicacion(AñoPublicacion);

        JOptionPane.showMessageDialog(null, "Libro registrado exitosamente.");


        return libro;
    }

    //ConsultarInformacionLibro

    public void consultarInformacionLibro(ArrayList<Libro> listaLibros) {
        int idLibro = Integer.parseInt(JOptionPane.showInputDialog("Id del libro: "));

        for (int i = 0; i < listaLibros.size(); i++) {
            if (listaLibros.get(i).getidLibro() == idLibro) {
                System.out.println("Información libro ID " + idLibro + " : ");
                listaLibros.get(i).getInformacion();
                return;
            }
        }
        System.out.println("Libro no encontrado");
    }

    //GenerarInformeLibrosDisponibles

    public void generarInformeLibrosDisponibles(ArrayList<Libro> listaLibros) {
        System.out.println("Libros Disponibles:");
        for (int i = 0; i < listaLibros.size(); i++) {
            if (listaLibros.get(i).getEstado() == 'D') {
                listaLibros.get(i).getInformacion();
                System.out.println();
            }
        }
    }


    //GenerarInformeLibrosPrestados

    public void generarInformeLibrosPrestados(ArrayList<Libro> listaLibros) {
        System.out.println("Libros Prestados:");
        for (int i = 0; i < listaLibros.size(); i++) {
            if (listaLibros.get(i).getEstado() == 'P') {
                listaLibros.get(i).getInformacion();
                System.out.println();
            }
        }
    }


    //GenerarInformeLibrosReservados

    public void generarInformeLibrosReservados(ArrayList<Libro> listaLibros) {
        System.out.println("Libros Reservados:");
        for (int i = 0; i < listaLibros.size(); i++) {
            if (listaLibros.get(i).getEstado() == 'R') {
                listaLibros.get(i).getInformacion();
                System.out.println();
            }
        }
    }



    // Constructor vacio para el main.
    public Bibliotecario() {

    }

}

