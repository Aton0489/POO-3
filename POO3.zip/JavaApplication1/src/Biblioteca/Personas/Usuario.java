/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Biblioteca.Personas;

/**
 *
 * @author omuri
 */
public class Usuario {
    private int id;
    private String Nombre;
    private String Telefono;
    private String Correo;


    public Usuario(int id, String Nombre, String Telefono, String Correo){
        this.id = id;
        this.Nombre = Nombre;
        this.Telefono = Telefono;
        this.Correo = Correo;
    }


    public Usuario(){

    }


    //Getters

    //id
    public int gettid(){
        return id;
    }

    //Nombre
    public String getNombre(){
        return Nombre;
    }

    //Telefono
    public String getTelefono(){
        return Telefono;
    }

    //Correo
    public String getCorreo(){
        return Correo;
    }

    //Setters

    //id
    public void setid(int id){
        this.id = id;
    }

    //Nombre
    public void setNombre(String Nombre){
        this.Nombre = Nombre;
    }

    //Telefono
    public void setTelefono(String Telefono){
        this.Telefono = Telefono;
    }

    //Correo
    public void setCorreo(String Correo){
        this.Correo = Correo;
    }
}

