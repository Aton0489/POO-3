/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Biblioteca.Personas;

/**
 *
 * @author omuri
 */
import java.util.ArrayList;
import javax.swing.JOptionPane;


public class Cliente extends Usuario {

    private ArrayList<Libro> librosPrestados = new ArrayList<Libro>();
    private ArrayList<Libro> librosReservados = new ArrayList<Libro>();

    //Constructorc Cliente con los atributos
    public Cliente(int id, String Nombre, String Telefono, String Correo){
        super(id, Nombre, Telefono, Correo);
    }

    //Metodos


    //Realizar un Prestamo
    public void realizarPrestamo(Libro libro, ArrayList<Libro> listaDispo ){
        int LSolicitado = Integer.parseInt(JOptionPane.showInputDialog("Id del libro:"));

        for(int i = 0; i< listaDispo.size(); i++){
            if(LSolicitado == listaDispo.get(i).getidLibro()){
                if(listaDispo.get(i).getEstado() == 'D'){
                    System.out.println("Solitidud realizada exitozamente");
                    listaDispo.get(i).prestarLibro();
                    librosPrestados.add(libro);

                    break;
                } else {
                    System.out.println("Libro no disponible");
                }
            } else {
                System.out.println("Libro invalido, no existe");
            }
        }
    }


    //Realizar una Devolucion
    public void realizarDevolucion(Libro libro, ArrayList<Libro> listaDispo){

        int Devolucion = Integer.parseInt(JOptionPane.showInputDialog("Id del libro: "));

        for(int i = 0; i < listaDispo.size(); i++){
            if(Devolucion == listaDispo.get(i).getidLibro()){
                if(listaDispo.get(i).getEstado() == 'P'){
                    System.out.println("Devolucion realizada exitozamente");
                    listaDispo.get(i).DevolverLibro();
                    librosPrestados.remove(libro);
                    break;
                } else {
                    System.out.println("Ese libro no a sido prestado.");
                }
            }
        }
    }

    //Consultar los libros Prestados

    public void consultarLibrosPrestados(ArrayList<Libro> listaLibros){
        System.out.println("Libros Reservados:");
        for(int i = 0; i < librosReservados.size(); i++){
            librosReservados.get(i).getInformacion();
        }
    }


    //Consultar los libros Reservados
    public void consultarLibrosReservados(){
        System.out.println("Libros Reservados:");
        for(int i = 0; i < librosReservados.size(); i++){
            librosReservados.get(i).getInformacion();
        }
    }


    //Constructor vacio para uso en main
    public Cliente() {

    }

}
