/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Biblioteca;

/**
 *
 * @author omuri
 */
import java.util.ArrayList;
import javax.swing.JOptionPane; //Importamos JOptionPane de paquete javax.swing para mostrar cuadros de dialogo sencillos.


public class Libro {
    //Definicion de atributos:
    private int idLibro;
    private String Titulo;
    private String Autor;
    private String Genero;
    private int AñoPublicacion;
    private char Estado; // Indica si el libro está ‘D’ disponible para préstamo, ‘P’ prestado o ‘R’ reservado

    //Constructor de ClaseLibro con sus parametros (la informacion que contine/forma)
    public Libro(int idLibro, String Titulo, String Autor, String Genero, int AñoPublicacion, char estado){
        //Acontinuacion se mostrara la asignacion de los valores de cada parametro a la varaiable que le corresponde
        this.idLibro = idLibro;
        this.Titulo = Titulo;
        this.Autor = Autor;
        this.Genero = Genero;
        this.AñoPublicacion = AñoPublicacion;
        this.Estado = Estado;
    }

    //Getters

    //id del libro
    public int getidLibro(){
        return idLibro;
    }


    // Titulo
    public String getTitulo() {
        return Titulo;
    }

    //Autor
    public String getAutor() {
        return Autor;
    }

    //Genero
    public String getGenero() {
        return Genero;
    }

    //Año de publicacion
    public int getAñoPublicacion(){
        return AñoPublicacion;
    }

    //Estado del libros
    public char getEstado() {
        return Estado;
    }

    //Setters

    //id del libro
    public void setidLiblo(int idLibro){
        this.idLibro = idLibro;
    }


    // Titulo
    public void setTitulo(String titulo) {
        this.Titulo = Titulo;
    }


    //Autor
    public void setAutor(String autor) {
        this.Autor = Autor;
    }


    // Genero
    public void setGenero(String genero) {
        this.Genero = Genero;
    }

    // Año de publicacion
    public void setAñoPublicacion(int anioPublicacion) {
        this.AñoPublicacion = AñoPublicacion;
    }


    //Estado del libro
    public void setEstado(char Estado){
        this.Estado = Estado;
    }



    // Obtener informacion sobre el libro

    public void getInformacion() {
        System.out.println("ID: " + idLibro + "\nTítulo: " + Titulo + "\nAutor: " + Autor + "\nGénero: " + Genero +
                "\nAño de Publicación: " + AñoPublicacion + "\nEstado: " + Estado);
    }

    // Prestar Libro
    public void prestarLibro(){
        this.setEstado('P'); //Prestamo
    }

    //DevolverLibro
    public void DevolverLibro(){
        this.setEstado('D'); //Disponible
    }

    //ReservarLibro
    public void reservarLibro(ArrayList<Libro> libros) {
        int libroReserva = Integer.parseInt(JOptionPane.showInputDialog("Id del libro:"));
        for (int i = 0; i < libros.size(); i++) {
            if (libroReserva == libros.get(i).getidLibro()) {
                if (libros.get(i).getEstado() == 'D' || libros.get(i).getEstado() == 'P') {
                    libros.get(i).setEstado('R');
                    JOptionPane.showMessageDialog(null, "libro reservado exitosamente.");
                    return;
                } else {
                    JOptionPane.showMessageDialog(null, "Libro no disponible para reserva.");
                    return;
                }
            }
        }
        JOptionPane.showMessageDialog(null, "Id invalido, no existe un libro con ese ID");
    }


    //Constructor vacio para uso en el main.
    public Libro() {

    }

}

