/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Biblioteca;

/**
 *
 * @author omuri
 */
import javax.swing.JOptionPane;
import java.util.ArrayList;



public class Gestion {
    public static void main(String[] args) {

        int MenuUsuarios = Integer.parseInt(JOptionPane.showInputDialog(" Vienvenido a la Biblioteca  \n 1. Bibliotecario \n 2. Cliente \n Salir"));

        switch(MenuUsuarios){
            case 1:
                int MenuBibliotecario;
                do{ MenuBibliotecario = Integer.parseInt(JOptionPane.showInputDialog(" BIBLIOTECARIO \n" +
                        "1. Registrar nuevo libro\n" +
                        "2. Consultar información de un libro\n" +
                        "3. Generar informe de libros disponibles\n" +
                        "4. Generar informe de libros prestados\n" +
                        "5. Generar informe de libros reservados\n" +
                        "6. Volver al menú principal"));

                    switch(MenuBibliotecario){
                        case 1:
                        case 2:
                        case 3:
                        case 4:
                        case 5:
                        case 6:
                            break;
                    }

                }while(MenuUsuarios != 6);
                break;

            case 2:

                int MenuCliente;
                do{ MenuCliente = Integer.parseInt(JOptionPane.showInputDialog(" CLIENTE \n" +
                        "1. Solicitar préstamo de libro\n" +
                        "2. Realizar devolución de libro\n" +
                        "3. Consultar libros prestados\n" +
                        "4. Consultar libros reservados\n" +
                        "5. Reservar libro\n" +
                        "6. Ver libros disponibles\n" +
                        "7. Volver al menú principal"));

                    switch(MenuCliente){
                        case 1:
                        case 2:
                        case 3:
                        case 4:
                        case 5:
                        case 6:
                        case 7:
                            break;

                    }

                }while(MenuUsuarios != 7);
                break;

            case 3:

                break;

        }
    }


    //2 Bibliotecarios:
    public static ArrayList<Bibliotecario> Bibliotecarios(){
        ArrayList<Bibliotecario> Bibliotecarios = new ArrayList<Bibliotecario>();

        //BIBLIOTECARIO 1
        Bibliotecario BibliotecarioNu1 = new Bibliotecario();
        BibliotecarioNu1.setNombre("Jose");
        BibliotecarioNu1.setContraseña(123);
        BibliotecarioNu1.setTelefono("3108543246");
        BibliotecarioNu1.setCorreo("JoselitoElLindo@Gmail.com");
        Bibliotecarios.add(BibliotecarioNu1);

        //BIBLIOTECARIO 2
        Bibliotecario BibliotecarioNu2 = new Bibliotecario();
        BibliotecarioNu2.setNombre("BUDA");
        BibliotecarioNu2.setContraseña(111);
        BibliotecarioNu2.setTelefono("3128593347");
        BibliotecarioNu2.setCorreo("SoloBUDISMOmiPay@Gmail.com");
        Bibliotecarios.add(BibliotecarioNu2);

        return Bibliotecarios;
    }

    //5 Libros Disponibles
    public static ArrayList<Libro> LibrosDisponibles(){

        ArrayList<Libro> LibrosDeLaBiblioteca = new ArrayList<>();

        //Libro 1
        Libro libroNu1 = new Libro();
        libroNu1.setidLiblo(1010);
        libroNu1.setTitulo("Harry Potter");
        libroNu1.setAutor(" yanicua escobar");
        libroNu1.setGenero("Historia");
        libroNu1.setAñoPublicacion(2020);
        libroNu1.setEstado('D');
        LibrosDeLaBiblioteca.add(libroNu1);

        //Libro 2
        Libro libroNu2 = new Libro();
        libroNu2.setidLiblo(2020);
        libroNu2.setTitulo("Hunger Games");
        libroNu2.setAutor("Uribe Para");
        libroNu2.setGenero("Drama");
        libroNu2.setAñoPublicacion(2014);
        libroNu2.setEstado('D');
        LibrosDeLaBiblioteca.add(libroNu2);

        //Libro 3
        Libro libroNu3 = new Libro();
        libroNu3.setidLiblo(3030);
        libroNu3.setTitulo("La segunda Guerra Mundial");
        libroNu3.setAutor("Drake santos");
        libroNu3.setGenero("Comedia");
        libroNu3.setAñoPublicacion(1200);
        libroNu3.setEstado('D');
        LibrosDeLaBiblioteca.add(libroNu3);

        //Libro 4
        Libro libroNu4 = new Libro();
        libroNu4.setidLiblo(4040);
        libroNu4.setTitulo("¿Que prefieres?");
        libroNu4.setAutor("Donald Trump");
        libroNu4.setGenero("Terror");
        libroNu4.setAñoPublicacion(2024);
        libroNu4.setEstado('D');
        LibrosDeLaBiblioteca.add(libroNu4);

        //Libro 5
        Libro libroNu5 = new Libro();
        libroNu5.setidLiblo(5050);
        libroNu5.setTitulo("Quieres ser tu propio jefe");
        libroNu5.setAutor("Luis Contreras");
        libroNu5.setGenero("Auto Superacion");
        libroNu5.setAñoPublicacion(2015);
        libroNu5.setEstado('D');
        LibrosDeLaBiblioteca.add(libroNu5);

        return LibrosDeLaBiblioteca;

    }

    public static ArrayList<Libro> LibrosEnPrestamo(ArrayList<Libro> LibrosDeLaBiblioteca){

        //Libro en prestamo 1
        Libro libroNu6 = new Libro();
        libroNu6.setidLiblo(6060);
        libroNu6.setTitulo("El manimoto causa cancer?");
        libroNu6.setAutor("Donlad Trump");
        libroNu6.setGenero("Terror");
        libroNu6.setAñoPublicacion(1999);
        libroNu6.setEstado('P');
        LibrosDeLaBiblioteca.add(libroNu6);


        //Libro en prestamo 2
        Libro libroNu7 = new Libro();
        libroNu7.setidLiblo(7070);
        libroNu7.setTitulo("La esquizofrenia");
        libroNu7.setAutor("Jhon Alejandro");
        libroNu7.setGenero("Drama");
        libroNu7.setAñoPublicacion(2099);
        libroNu7.setEstado('P');
        LibrosDeLaBiblioteca.add(libroNu7);


        //Libro en prestamo 3
        Libro libroNu8 = new Libro();
        libroNu8.setidLiblo(8080);
        libroNu8.setTitulo("Jesus");
        libroNu8.setAutor("Simon Bolivar");
        libroNu8.setGenero("Accion");
        libroNu8.setAñoPublicacion(1734);
        libroNu8.setEstado('P');
        LibrosDeLaBiblioteca.add(libroNu8);

        return LibrosDeLaBiblioteca;
    }


    // 2 Libros Reservados
    public static ArrayList<Libro> LibrosEnReservada(ArrayList<Libro> LibrosDeLaBiblioteca) {

        //Libro reserva 1
        Libro libroNu9 = new Libro();
        libroNu9.setidLiblo(9090);
        libroNu9.setTitulo("Bogota o Medellin");
        libroNu9.setAutor("Maluma Bby");
        libroNu9.setGenero("Ficcion");
        libroNu9.setAñoPublicacion(2013);
        libroNu9.setEstado('R');
        LibrosDeLaBiblioteca.add(libroNu9);

        //Libro reserva 2
        Libro libroNu10 = new Libro();
        libroNu10.setidLiblo(1212);
        libroNu10.setTitulo("Independencia de BarrancaVermeja");
        libroNu10.setAutor("Tal-Cual");
        libroNu10.setGenero("Terror");
        libroNu10.setAñoPublicacion(2000);
        libroNu10.setEstado('R');
        LibrosDeLaBiblioteca.add(libroNu10);

        return LibrosDeLaBiblioteca;

    }



    // 4 Clientes
    public static ArrayList<Cliente> ClientesBiblioteca(){
        ArrayList<Cliente> ClientesBiblioteca = new ArrayList<Cliente>();

        //Cliente 1
        Cliente clienteNu1 = new Cliente();
        clienteNu1.setid(111);
        clienteNu1.setNombre("Olvert Muriel");
        clienteNu1.setTelefono("3128806346");
        clienteNu1.setCorreo("OlivertoMuri@gmail.com");
        ClientesBiblioteca.add(clienteNu1);

        //Cliente 2
        Cliente clienteNu2 = new Cliente();
        clienteNu2.setid(222);
        clienteNu2.setNombre("Daniel Felipe");
        clienteNu2.setTelefono("3016026375");
        clienteNu2.setCorreo("DanielitoElManquito@gmail.com");
        ClientesBiblioteca.add(clienteNu2);

        //Cliente 3
        Cliente clienteNu3 = new Cliente();
        clienteNu3.setid(333);
        clienteNu3.setNombre("Anthony Nope");
        clienteNu3.setTelefono("3108532686");
        clienteNu3.setCorreo("AnthonyNopeRendon@gmail.com");
        ClientesBiblioteca.add(clienteNu3);

        //Cliente 4
        Cliente clienteNu4 = new Cliente();
        clienteNu4.setid(200);
        clienteNu4.setNombre("Messi");
        clienteNu4.setTelefono("99999999");
        clienteNu4.setCorreo("Messi@gmail.com");
        ClientesBiblioteca.add(clienteNu4);

        return ClientesBiblioteca;

    }




}
